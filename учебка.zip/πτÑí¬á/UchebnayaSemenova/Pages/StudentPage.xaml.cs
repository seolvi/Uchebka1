﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using UchebnayaSemenova.Bases;


namespace UchebnayaSemenova.Pages
{
    /// <summary>
    /// Логика взаимодействия для StudentPage.xaml
    /// </summary>
    public partial class StudentPage : Page
    {
        public StudentPage()
        {
            InitializeComponent();
            //StudentP.ItemsSource = App.db.Student.ToList();
            StudentP.Items.Clear();
            Refresh();
            if (!App.isAdmin)
            {
                AddBtn.Visibility = Visibility.Hidden;
                DelBtn.Visibility = Visibility.Hidden;
                EditBtn.Visibility = Visibility.Hidden;
            }
            
        }


        private void Refresh()
        {
            IEnumerable<Student> SortedStudent = App.db.Student;
            if (SortList.SelectedIndex == 0)
            {
                SortedStudent = SortedStudent.OrderBy(x => x.Surname_Student);
            }
            else if (SortList.SelectedIndex == 1)
            {
                SortedStudent = SortedStudent.OrderByDescending(x => x.Surname_Student);
            }

            if (FiltrList.SelectedIndex == 0)
                SortedStudent = SortedStudent.Where(x => x.Specs.Direction == "Прикладная математика");
            if (FiltrList.SelectedIndex == 1)
                SortedStudent = SortedStudent.Where(x => x.Specs.Direction == "Информационные системы и технологии");
            if (FiltrList.SelectedIndex == 2)
                SortedStudent = SortedStudent.Where(x => x.Specs.Direction == "Прикладная информатика");
            if (FiltrList.SelectedIndex == 3)
                SortedStudent = SortedStudent.Where(x => x.Specs.Direction == "Ядерные физика и технологии");
            if (FiltrList.SelectedIndex == 4)
                SortedStudent = SortedStudent.Where(x => x.Specs.Direction == "Бизнес-информатика");

            if (SearchTb.Text != null)
            {

                StudentP.ItemsSource = SortedStudent.ToList().Where(x => x.IsDeleted != Convert.ToBoolean(1));
            }

            StudentP.ItemsSource = SortedStudent.ToList();
        }
        private void SortList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Refresh();
        }

        private void FiltrList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Refresh();
        }

        private void SearchTb_TextChanged(object sender, TextChangedEventArgs e)
        {
            Refresh();
        }

     

        private void AddBtn_Click_2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditStudentPage(new Student(), "add"));
        }

        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            var student = (Student)StudentP.SelectedItem;
            if (student == null)
                MessageBox.Show("Для редактирования выберите данные!");
            NavigationService.Navigate(new AddEditStudentPage(student, "redact"));
        }

        private void DelBtn_Click(object sender, RoutedEventArgs e)
        {
            var student = (Student)StudentP.SelectedItem;
            student.IsDeleted = Convert.ToBoolean(1);
            Refresh();
            App.db.SaveChanges();
        }
    }
}

